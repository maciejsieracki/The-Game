# DESIGN → UI · Miasto W3 v3 (1E) — handoff

Kierunek 1E (Painted Imperial). Tokeny FROZEN v1.0. Zero emoji. Baseline gry używa „/t" — zostaje.

## Plik
`brand-book/The Game - Ekran Miasto W3 v3 (1E).dc.html` — 4 klatki odwzorowane 1:1 z playtestu baseline.

## Klatki
1. **Spichlerz / Wzrost** — rail 7 medalionów (Spichlerz, Handel, Praca, Budowa, Zdrowie, Kultura, Religia), tytuł + „i SZCZEGÓŁY", pigułki (Ludność, Do +1, Netto, Bufor) z „/t", slider Wzrost↔Armia, stopka „Surowce w zasięgu".
2. **Budowa** — kolejka produkcji + pasek postępu + lista dostępnych (koszt pracy, tury).
3. **Chrome mapy 3D** — górny pasek zasobów (B02), baner miasta, „Zakończ turę".
4. **Menu gry (☰)** — Wróć do gry / Zapisz / Wczytaj / Nowa gra / Menu główne (1:1 gamePauseMenu.ts). Esc z miasta → mapa świata (NIE modal Pauza). Wiki = osobny przycisk toolbar.

## v3.1b (sign-off · 2026-07-04)
- **A · Surowce = stopka kolumny** — na samym dole prawej kolumny, osobno od treści zakładki. Grid 2×2, **ikona + nazwa ONLY** (bez „+2 żywność”). Wspólna pod każdą zakładką (Spichlerz, Handel, …) — zmienia się tylko góra. Spichlerz BEZ surowców w środku karty.
- **B · Esc + menu** — Esc→mapa świata; Menu gry (☰) = 5 pozycji jak wyżej; Wiki poza menu (toolbar); chrome mapy pokazuje Menu + Wiki.
- Rail = 7 medalionów (NIE 9). Nie ruszano: lewy rail Budowa/Rekrutacja, logika, „/t”.

## Zasady integracji
- Kolory/geometria wyłącznie z `--tg-*` (tokens.css). Ikony przez `iconRegistry` / mapy JSON.
- Rail = 7 medalionów (NIE 9 — stare W3 nieaktualne).
- „/t" zostaje przy wartościach na turę (zgodnie z baseline).
- Panel miasta = dim opaque nad mapą; górny pasek + Wiki widoczne, dolny chrome mapy ukryty.

## Status
APPROVE (layout / 4 klatki / chrome). Ewentualne poprawki wizualne po playteście vs `gra-kanon/START.html` (24h).

*Lane UI · The Game · 1E · Miasto W3 v3.1b · 2026-07-04*
