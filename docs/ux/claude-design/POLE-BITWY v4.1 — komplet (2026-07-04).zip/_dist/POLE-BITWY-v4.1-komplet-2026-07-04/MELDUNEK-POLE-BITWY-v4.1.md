# MELDUNEK — POLE-BITWY v4.1 komplet (2026-07-04)

Paczka: `POLE-BITWY-v4.1-komplet-2026-07-04.zip`. Skin/szata 1E — lane portuje CSS, logika bez zmian.

## Pliki
1. **The Game - C06 Deployment v4 2026-07-04 (1E).dc.html** — faza rozstawiania, 3 stany (Deployment / AUTO / Ręczne).
2. **The Game - C06 Popup Strategia v4 2026-07-04 (1E).dc.html** — popup Priorytety armii/grupy w 1E.
3. **The Game - C09 Roster lewy panel v4 2026-07-04 (1E).dc.html** — roster kart jednostek.
4. **support.js** — runtime .dc.html (obok plików).
5. **DESIGN-do-UI_POLE-BITWY-poprawki-v4.1.md** — handoff lane.

## Poprawki tej sesji (C06 Deployment)
- VS → **skrzyżowane miecze** w górnym pasku.
- Miecze + pasek mocy **wyrównane do pionowej linii podziału mapy** i styku zielony/czerwony — wszystkie 3 plansze (Deployment/AUTO = 960 px, Ręczne = 1144 px / `50% + 184px`).
- Cluster statystyk: infografiki **koń** (konnica) · **skrzyżowane miecze** (piechota) · **łuk** (łucznicy) — zamiast domyślnych glifów.
- Nagłówki grup rosteru: „Grupa 1 · N".
- Paski mocy w stanach AUTO / Ręczne ustawione 50/50 (styk na środku).

## Strategia v4
- Dropdowny w ciemno‑złotej ramce 1E (nie systemowe granatowe), mini‑medaliony typów, strzałka ▾.
- Sekcje: Priorytety armii (Konnica/Łucznicy/Piechota ×3) + Priorytety grupy.
- „Przywróć domyślne (armia)", scroll 1E, zakotwiczenie nad przyciskiem STRATEGIA.

## Status
POLE-BITWY v4.1 — dopięte po stronie Design. Zero emoji, kanon 1E. Lane: port CSS.

*Lane UI · The Game · 1E · POLE-BITWY v4.1 · 2026-07-04*
